# Professional 3-Factor Bias Tracker

Daily bias tracker for NQ and GC futures using what actually works in professional trading.

## The System

### 3 Factors That Determine Bias:

1. **Market Structure (Daily Chart)**
   - Higher Highs + Higher Lows = BULLISH
   - Lower Highs + Lower Lows = BEARISH

2. **VWAP Position**
   - Price Above VWAP = BULLISH (66% correlation)
   - Price Below VWAP = BEARISH

3. **Opening Range (First 30min)**
   - Break Above OR High = BULLISH
   - Break Below OR Low = BEARISH

### How It Works:

- **3/3 factors agree** = STRONG BULLISH or STRONG BEARISH
- **2/3 factors agree** = BULLISH or BEARISH
- **Conflicting signals** = NEUTRAL (stay out)

## Quick Start

### 1. Install
```bash
pip install -r requirements.txt
```

### 2. Test It
```bash
python test_pro_bias.py
```

You'll get:
```
NQ: STRONG BEARISH
$24,844.50
Structure DOWN | Below VWAP | Broke OR Low

GC: BEARISH
$4,002.70
Structure DOWN | Broke OR Low
```

### 3. Run Hourly Tracker
```bash
python bias_tracker.py
```

Sends notifications every hour on the hour. Runs continuously until you stop it (Ctrl+C).

## How to Use With Forever Model

**Your Forever Model uses 15m/60m FVG entries - This tells you WHICH DIRECTION:**

### Strong Bullish:
```
NQ: STRONG BULLISH
Structure UP | Above VWAP | Broke OR High

Action: ONLY take LONG FVG setups today
```

### Strong Bearish:
```
NQ: STRONG BEARISH
Structure DOWN | Below VWAP | Broke OR Low

Action: ONLY take SHORT FVG setups today
```

### Neutral:
```
NQ: NEUTRAL

Action: Stay out or be VERY selective
```

## Why This Works

### Based on Professional Trading:

1. **Market Structure** - What institutions follow (HH/HL vs LH/LL)
2. **VWAP** - Where institutions accumulated (66% predictive)
3. **Opening Range** - Often sets high/low of day

### Multiple Confirmation:

- When all 3 agree = High probability direction
- When 2/3 agree = Clear bias
- When conflicting = No edge, stay out

### Real Example:

**NQ: STRONG BEARISH (All 3 Agree)**
- ✓ Structure: Making Lower Highs/Lower Lows
- ✓ VWAP: Below by 0.78%
- ✓ Opening Range: Broke below OR low

**Result:** Only take SHORT FVG setups = Aligned with institutional flow

## Files

**Core:**
- `config.py` - API credentials
- `topstepx_client.py` - Live data from TopStepX
- `pro_bias_engine.py` - 3-factor bias system
- `pushover_client.py` - Phone notifications
- `bias_tracker.py` - Hourly monitoring

**Testing:**
- `test_pro_bias.py` - Test and send notification

## What You Get

**Phone notification (clear & actionable):**
```
NQ: STRONG BEARISH
$24,844.50
Structure DOWN | Below VWAP | Broke OR Low

GC: BEARISH
$4,002.70
Structure DOWN | Broke OR Low
```

**Console output (detailed):**
```
[NQ] STRONG BEARISH - $24,844.50
  Structure: BEARISH
  VWAP: BEARISH ($25,040.08)
  Opening: BEARISH

Reasoning:
  All 3 factors bearish
  1. Structure: BEARISH - Making LH/LL (downtrend)
  2. VWAP: BEARISH - Below VWAP by 0.78%
  3. Opening: BEARISH - Broke below OR low ($25,241.25)
```

## Settings

Edit `config.py`:

```python
# Symbols to track
SYMBOLS = ["NQZ5", "GCZ5"]

# Update frequency
UPDATE_INTERVAL = 3600  # 1 hour

# Trading hours (ET)
SESSION_START_HOUR = 9
SESSION_START_MINUTE = 30
SESSION_END_HOUR = 16
SESSION_END_MINUTE = 0
```

## Why This Solves Your Problem

**Your Issue:** "The model works, I just trade against trend sometimes"

**Solution:** This tells you THE TREND before you enter

**Before:**
- See perfect 15m FVG short setup
- Take it
- Price reverses up
- Reason: All 3 factors were bullish, you traded against them

**After:**
- Get notification: "NQ: STRONG BULLISH"
- See perfect 15m FVG short setup
- Skip it (against bias)
- Wait for long FVG
- Price goes up, you catch the move

**Simple:** Don't trade against the 3-factor bias.
