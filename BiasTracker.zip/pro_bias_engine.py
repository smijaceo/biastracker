"""
Professional Bias Engine - 3-Factor Confirmation System

Based on what actually works:
1. Market Structure (Daily) - HH/HL vs LH/LL
2. VWAP Position - Above vs Below
3. Opening Range - Break up vs down

2/3 agree = Clear bias
3/3 agree = Strong bias
Conflicting = Neutral
"""

import pandas as pd
import numpy as np
from typing import Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, time as dt_time


@dataclass
class ProBias:
    """Professional bias state"""
    symbol: str
    bias: str  # "STRONG BULLISH", "BULLISH", "NEUTRAL", "BEARISH", "STRONG BEARISH"
    current_price: float

    # Factor results
    market_structure: str  # "BULLISH", "BEARISH", "NEUTRAL"
    vwap_position: str     # "BULLISH", "BEARISH", "NEUTRAL"
    opening_range: str     # "BULLISH", "BEARISH", "NEUTRAL"

    # Reference values
    vwap: float
    or_high: float
    or_low: float

    # Explanation
    reasoning: str
    timestamp: datetime


class ProBiasEngine:
    """
    3-Factor Professional Bias Engine

    Combines what institutional traders actually use
    """

    def __init__(self):
        pass

    def calculate_market_structure(self, daily_df: pd.DataFrame) -> Tuple[str, str]:
        """
        Analyze daily market structure

        Returns:
            (bias, detail)
        """
        if daily_df is None or daily_df.empty or len(daily_df) < 5:
            return "NEUTRAL", "Insufficient data"

        # Get last 5 days
        recent = daily_df.tail(5)
        highs = recent['high'].values
        lows = recent['low'].values

        # Count higher highs and higher lows
        higher_highs = 0
        higher_lows = 0
        lower_highs = 0
        lower_lows = 0

        for i in range(1, len(highs)):
            if highs[i] > highs[i-1]:
                higher_highs += 1
            elif highs[i] < highs[i-1]:
                lower_highs += 1

            if lows[i] > lows[i-1]:
                higher_lows += 1
            elif lows[i] < lows[i-1]:
                lower_lows += 1

        # Determine structure
        if higher_highs >= 3 and higher_lows >= 3:
            return "BULLISH", "Making HH/HL (uptrend)"
        elif lower_highs >= 3 and lower_lows >= 3:
            return "BEARISH", "Making LH/LL (downtrend)"
        else:
            return "NEUTRAL", "Mixed structure"

    def calculate_vwap(self, intraday_df: pd.DataFrame) -> Tuple[float, str, str]:
        """
        Calculate VWAP and position

        Note: Timestamps in dataframe are UTC. 9:30 AM ET = 14:30 UTC (during EST)

        Returns:
            (vwap_value, bias, detail)
        """
        if intraday_df is None or intraday_df.empty:
            return None, "NEUTRAL", "No intraday data"

        # 9:30 AM ET = 14:30 UTC (during EST/winter) or 13:30 UTC (during EDT/summer)
        # Determine if we're in EST or EDT by checking current time
        from datetime import datetime
        import pytz
        eastern = pytz.timezone('US/Eastern')
        now_et = datetime.now(eastern)
        session_start_et = now_et.replace(hour=9, minute=30, second=0, microsecond=0)
        session_start_utc = session_start_et.astimezone(pytz.UTC)

        # Get UTC hour for session start (14 in winter, 13 in summer)
        session_start_hour = session_start_utc.hour
        session_start_time = dt_time(session_start_hour, 30)

        # Filter for current trading session (9:30 AM ET onwards in UTC)
        session_data = intraday_df[intraday_df['timestamp'].dt.time >= session_start_time]

        # If no session data, use all data
        if session_data.empty:
            session_data = intraday_df

        # Calculate VWAP from session start
        typical_price = (session_data['high'] + session_data['low'] + session_data['close']) / 3
        vwap = (typical_price * session_data['volume']).sum() / session_data['volume'].sum()

        # Get current price
        current_price = intraday_df.iloc[-1]['close']

        # Determine position
        diff_pct = ((current_price - vwap) / vwap) * 100

        if diff_pct > 0.2:
            return vwap, "BULLISH", f"Above VWAP by {diff_pct:.2f}%"
        elif diff_pct < -0.2:
            return vwap, "BEARISH", f"Below VWAP by {abs(diff_pct):.2f}%"
        else:
            return vwap, "NEUTRAL", f"At VWAP ({diff_pct:.2f}%)"

    def calculate_opening_range(self, intraday_df: pd.DataFrame) -> Tuple[float, float, str, str]:
        """
        Calculate opening range (first 30 min) and break direction

        Note: Timestamps in dataframe are UTC.
        9:30 AM ET = 14:30 UTC (EST) or 13:30 UTC (EDT)
        10:00 AM ET = 15:00 UTC (EST) or 14:00 UTC (EDT)

        Returns:
            (or_high, or_low, bias, detail)
        """
        if intraday_df is None or intraday_df.empty:
            return None, None, "NEUTRAL", "No intraday data"

        # Determine UTC times for 9:30 AM ET and 10:00 AM ET
        from datetime import datetime
        import pytz
        eastern = pytz.timezone('US/Eastern')
        now_et = datetime.now(eastern)

        session_start_et = now_et.replace(hour=9, minute=30, second=0, microsecond=0)
        or_end_et = now_et.replace(hour=10, minute=0, second=0, microsecond=0)

        session_start_utc = session_start_et.astimezone(pytz.UTC)
        or_end_utc = or_end_et.astimezone(pytz.UTC)

        # Convert to time objects for comparison
        session_start_time = dt_time(session_start_utc.hour, session_start_utc.minute)
        or_end_time = dt_time(or_end_utc.hour, or_end_utc.minute)

        # Filter for opening range using UTC times
        or_bars = intraday_df[
            (intraday_df['timestamp'].dt.time >= session_start_time) &
            (intraday_df['timestamp'].dt.time < or_end_time)
        ]

        if len(or_bars) < 5:  # Need at least some bars
            # Use first 30 bars as fallback
            or_bars = intraday_df.head(30)

        or_high = or_bars['high'].max()
        or_low = or_bars['low'].min()

        # Get current price
        current_price = intraday_df.iloc[-1]['close']

        # Determine break
        if current_price > or_high:
            return or_high, or_low, "BULLISH", f"Broke above OR high (${or_high:.2f})"
        elif current_price < or_low:
            return or_high, or_low, "BEARISH", f"Broke below OR low (${or_low:.2f})"
        else:
            return or_high, or_low, "NEUTRAL", f"Inside OR (${or_low:.2f} - ${or_high:.2f})"

    def combine_factors(
        self,
        structure: str,
        vwap: str,
        opening: str
    ) -> Tuple[str, str]:
        """
        Combine 3 factors to determine final bias

        Returns:
            (bias, reasoning)
        """
        # Count votes
        bullish_votes = sum([
            structure == "BULLISH",
            vwap == "BULLISH",
            opening == "BULLISH"
        ])

        bearish_votes = sum([
            structure == "BEARISH",
            vwap == "BEARISH",
            opening == "BEARISH"
        ])

        # Determine bias
        if bullish_votes == 3:
            return "STRONG BULLISH", "All 3 factors bullish"
        elif bullish_votes == 2:
            return "BULLISH", "2/3 factors bullish"
        elif bearish_votes == 3:
            return "STRONG BEARISH", "All 3 factors bearish"
        elif bearish_votes == 2:
            return "BEARISH", "2/3 factors bearish"
        else:
            return "NEUTRAL", "Conflicting signals"

    def calculate_bias(
        self,
        symbol: str,
        daily_df: pd.DataFrame,
        intraday_df: pd.DataFrame,
        realtime_df: pd.DataFrame = None
    ) -> Optional[ProBias]:
        """
        Calculate professional bias using 3-factor system

        Args:
            symbol: Trading symbol
            daily_df: Daily bars for structure
            intraday_df: 5m bars for VWAP and opening range
            realtime_df: 1m bars for real-time current price (optional)

        Returns:
            ProBias object
        """
        if daily_df is None or daily_df.empty:
            print(f"[PRO BIAS] No daily data for {symbol}")
            return None

        if intraday_df is None or intraday_df.empty:
            print(f"[PRO BIAS] No intraday data for {symbol}")
            return None

        # Get current price from 1m bars if available (most recent), otherwise use 5m
        if realtime_df is not None and not realtime_df.empty:
            current_price = realtime_df.iloc[-1]['close']
        else:
            current_price = intraday_df.iloc[-1]['close']

        # Factor 1: Market Structure
        structure_bias, structure_detail = self.calculate_market_structure(daily_df)

        # Factor 2: VWAP Position
        vwap_value, vwap_bias, vwap_detail = self.calculate_vwap(intraday_df)

        # Factor 3: Opening Range
        or_high, or_low, opening_bias, opening_detail = self.calculate_opening_range(intraday_df)

        # Combine factors
        final_bias, combination_detail = self.combine_factors(
            structure_bias,
            vwap_bias,
            opening_bias
        )

        # Build reasoning
        reasoning = f"{combination_detail}\n"
        reasoning += f"1. Structure: {structure_bias} - {structure_detail}\n"
        reasoning += f"2. VWAP: {vwap_bias} - {vwap_detail}\n"
        reasoning += f"3. Opening: {opening_bias} - {opening_detail}"

        return ProBias(
            symbol=symbol,
            bias=final_bias,
            current_price=current_price,
            market_structure=structure_bias,
            vwap_position=vwap_bias,
            opening_range=opening_bias,
            vwap=vwap_value if vwap_value else 0,
            or_high=or_high if or_high else 0,
            or_low=or_low if or_low else 0,
            reasoning=reasoning,
            timestamp=datetime.now()
        )


if __name__ == "__main__":
    print("Professional Bias Engine - 3-Factor System")
    print("=" * 60)
    print("\nFactors:")
    print("1. Market Structure (Daily) - HH/HL vs LH/LL")
    print("2. VWAP Position - Above vs Below")
    print("3. Opening Range - Break up vs down")
    print("\nCombination:")
    print("- 3/3 agree = STRONG bias")
    print("- 2/3 agree = Clear bias")
    print("- Conflicting = NEUTRAL")
