"""
Main Bias Tracker - Monitors NQ and GC futures and sends Pushover alerts
"""

import time
from datetime import datetime, time as dt_time
from typing import Dict
import config
from topstepx_client import TopStepXClient
from pro_bias_engine import ProBiasEngine, ProBias
from pushover_client import PushoverClient


class BiasTracker:
    """Main application for tracking and notifying on intraday bias"""

    def __init__(self):
        print("Initializing Bias Tracker...")

        # Initialize clients
        self.data_client = TopStepXClient(
            api_key=config.TOPSTEPX_API_KEY,
            base_url=config.TOPSTEPX_BASE_URL,
            username=config.TOPSTEPX_USERNAME
        )

        self.bias_engine = ProBiasEngine()

        self.notifier = PushoverClient(
            user_key=config.PUSHOVER_USER_KEY,
            api_token=config.PUSHOVER_API_TOKEN
        )

        self.running = False
        self.last_states: Dict[str, ProBias] = {}

        print("Bias Tracker initialized successfully")

    def process_symbol(self, symbol: str):
        """Process a single symbol and send notifications if needed"""
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Processing {symbol}...")

        try:
            # Fetch data
            timeframe_data = self.data_client.get_multi_timeframe_data(symbol)

            # Calculate 3-factor bias (use 5m for VWAP/OR, 1m for current price)
            state = self.bias_engine.calculate_bias(
                symbol,
                timeframe_data['daily'],
                timeframe_data['5m'],
                timeframe_data.get('1m')
            )

            if state is None:
                print(f"[{symbol}] Could not calculate bias")
                return

            # Display current state
            short_name = symbol[:2]
            print(f"[{short_name}] {state.bias} - ${state.current_price:.2f}")
            print(f"  Structure: {state.market_structure}")
            print(f"  VWAP: {state.vwap_position} (${state.vwap:.2f})")
            print(f"  Opening: {state.opening_range}")

            # Send notification
            title = f"{short_name} Bias"

            # Determine priority
            if "STRONG" in state.bias:
                priority_level = 1
                sound = "cashregister"
            elif state.bias in ["BULLISH", "BEARISH"]:
                priority_level = 0
                sound = "cosmic"
            else:
                priority_level = -1
                sound = "none"

            # Build message
            message = f"{state.bias}\n${state.current_price:.2f}\n\n"

            # Add factors
            factors = []
            if state.market_structure == "BULLISH":
                factors.append("Structure UP")
            elif state.market_structure == "BEARISH":
                factors.append("Structure DOWN")

            if state.vwap_position == "BULLISH":
                factors.append("Above VWAP")
            elif state.vwap_position == "BEARISH":
                factors.append("Below VWAP")

            if state.opening_range == "BULLISH":
                factors.append("Broke OR High")
            elif state.opening_range == "BEARISH":
                factors.append("Broke OR Low")

            if factors:
                message += " | ".join(factors)

            self.notifier.send_notification(
                message=message,
                title=title,
                priority=priority_level,
                sound=sound
            )

            self.last_states[symbol] = state

        except Exception as e:
            print(f"[ERROR] Failed to process {symbol}: {e}")
            import traceback
            traceback.print_exc()

    def run_cycle(self):
        """Run one monitoring cycle for all symbols"""
        print(f"\n{'='*70}")
        print(f"Bias Update - {datetime.now().strftime('%Y-%m-%d %I:%M %p')}")
        print('='*70)

        for symbol in config.SYMBOLS:
            self.process_symbol(symbol)

        print(f"\n{'='*70}")
        print(f"Next update at the top of the next hour")
        print('='*70)

    def start(self):
        """Start the bias tracker"""
        print("\n" + "="*70)
        print("BIAS TRACKER STARTED")
        print("="*70)
        print(f"Monitoring: {', '.join(config.SYMBOLS)}")
        print(f"Updates: Every hour on the hour")
        print("="*70 + "\n")

        self.running = True

        try:
            # Send first update immediately
            self.run_cycle()

            # Then wait and send every hour on the hour
            while self.running:
                # Calculate seconds until next hour
                now = datetime.now()
                next_hour = now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
                seconds_until_next = (next_hour - now).total_seconds()

                print(f"\nWaiting {int(seconds_until_next)} seconds until {next_hour.strftime('%I:%M %p')}...")
                time.sleep(seconds_until_next)

                # Send update at the top of the hour
                self.run_cycle()

        except KeyboardInterrupt:
            print("\n\nStopping Bias Tracker...")
            self.stop()

    def stop(self):
        """Stop the bias tracker"""
        self.running = False
        print("Bias Tracker stopped")


def main():
    """Main entry point"""
    # Validate configuration
    if config.PUSHOVER_API_TOKEN == "your_pushover_api_token_here":
        print("\n⚠️  ERROR: Please configure your Pushover API token in config.py")
        print("\nYou need to set:")
        print("  - PUSHOVER_API_TOKEN")
        print("\nGet it from: https://pushover.net/apps/build")
        print("\nNote: Your TopStepX API key is already configured.")
        return

    # Create and start tracker
    tracker = BiasTracker()
    tracker.start()


if __name__ == "__main__":
    main()
