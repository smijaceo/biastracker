"""
TopStepX API client for fetching real-time futures data
"""

from typing import List, Dict, Optional
from datetime import datetime, timedelta
import pandas as pd
import requests
import config


class TopStepXClient:
    """
    Client for interacting with TopStepX REST API to fetch OHLC data

    Documentation: https://gateway.docs.projectx.com/
    """

    def __init__(self, api_key: str, base_url: str, username: str = None):
        self.api_key = api_key
        self.base_url = base_url
        self.username = username
        self.jwt_token = None
        self.token_expiry = None
        self.account_id = None
        self.contract_cache = {}  # Cache contract IDs

        # Authenticate and get account
        self._authenticate()
        self._get_account_id()

    def _authenticate(self):
        """Authenticate with API key and get JWT token"""
        try:
            url = f"{self.base_url}/api/Auth/loginKey"

            payload = {
                "apiKey": self.api_key
            }

            # Add username if provided
            if self.username:
                payload["userName"] = self.username

            response = requests.post(
                url,
                json=payload,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                self.jwt_token = data.get('token')
                self.token_expiry = datetime.now() + timedelta(hours=23)  # Valid 24 hours
                print("[TOPSTEPX] Authentication successful")
                return True
            else:
                print(f"[ERROR] Authentication failed: {response.status_code} - {response.text}")
                return False

        except Exception as e:
            print(f"[ERROR] Failed to authenticate: {e}")
            return False

    def _ensure_authenticated(self):
        """Check if token is valid, re-authenticate if needed"""
        if not self.jwt_token or not self.token_expiry:
            return self._authenticate()

        # Re-authenticate if token expires in less than 1 hour
        if datetime.now() + timedelta(hours=1) > self.token_expiry:
            print("[TOPSTEPX] Token expiring soon, re-authenticating...")
            return self._authenticate()

        return True

    def _get_headers(self) -> Dict[str, str]:
        """Get headers with JWT token for API requests"""
        self._ensure_authenticated()
        return {
            "Authorization": f"Bearer {self.jwt_token}",
            "Content-Type": "application/json"
        }

    def _get_account_id(self):
        """Get the account ID by searching accounts"""
        try:
            url = f"{self.base_url}/api/Account/search"

            response = requests.post(
                url,
                json={"onlyActiveAccounts": True},
                headers=self._get_headers(),
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()

                # Handle both array and object responses
                if isinstance(data, list) and len(data) > 0:
                    self.account_id = data[0].get('id') or data[0].get('accountId')
                elif isinstance(data, dict):
                    # Check if data is wrapped in a result key
                    accounts = data.get('result') or data.get('accounts') or [data]
                    if accounts and len(accounts) > 0:
                        self.account_id = accounts[0].get('id') or accounts[0].get('accountId')

                if self.account_id:
                    print(f"[TOPSTEPX] Found account ID: {self.account_id}")
                    return self.account_id
                else:
                    print(f"[ERROR] No account ID in response")
            else:
                print(f"[ERROR] Failed to get accounts: {response.status_code} - {response.text}")

        except Exception as e:
            print(f"[ERROR] Failed to get account ID: {e}")

        return None

    def _get_contract_id(self, symbol: str, live: bool = False) -> Optional[str]:
        """
        Get contract ID for a symbol

        Args:
            symbol: Futures symbol (e.g., 'NQ', 'GC')
            live: Whether to search for live contracts

        Returns:
            Contract ID string
        """
        # Check cache first
        cache_key = f"{symbol}_{live}"
        if cache_key in self.contract_cache:
            return self.contract_cache[cache_key]

        try:
            url = f"{self.base_url}/api/Contract/search"

            response = requests.post(
                url,
                json={
                    "searchText": symbol,
                    "live": live
                },
                headers=self._get_headers(),
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()

                # Handle response structure
                contracts = None
                if isinstance(data, dict):
                    contracts = data.get('contracts') or data.get('result')
                elif isinstance(data, list):
                    contracts = data

                if contracts and len(contracts) > 0:
                    # Filter for exact symbol match (case-insensitive)
                    matching = []
                    for c in contracts:
                        if isinstance(c, dict):
                            symbol_field = c.get('symbol', c.get('name', ''))
                            if symbol.upper() in symbol_field.upper():
                                matching.append(c)

                    if matching:
                        contract_id = matching[0].get('id') or matching[0].get('contractId')
                        self.contract_cache[cache_key] = contract_id
                        print(f"[TOPSTEPX] Found contract ID for {symbol}: {contract_id}")
                        return contract_id
                    else:
                        print(f"[WARNING] No exact match for {symbol}, using first result")
                        contract_id = contracts[0].get('id') or contracts[0].get('contractId') if isinstance(contracts[0], dict) else contracts[0]
                        self.contract_cache[cache_key] = contract_id
                        print(f"[TOPSTEPX] Using contract ID for {symbol}: {contract_id}")
                        return contract_id
                else:
                    print(f"[ERROR] No contracts found for {symbol}")
            else:
                print(f"[ERROR] Failed to search contracts: {response.status_code} - {response.text}")

        except Exception as e:
            print(f"[ERROR] Failed to get contract ID for {symbol}: {e}")

        return None

    def get_bars(
        self,
        symbol: str,
        start_time: datetime,
        end_time: datetime,
        unit: int = 2,  # 1=Second, 2=Minute, 3=Hour, 4=Day
        unit_number: int = 1,
        limit: int = 5000,
        live: bool = False  # Use False for simulated accounts
    ) -> Optional[pd.DataFrame]:
        """
        Retrieve OHLC bars for a symbol

        Args:
            symbol: Futures symbol (e.g., 'NQ', 'GC')
            start_time: Start datetime
            end_time: End datetime
            unit: Time unit (1=Second, 2=Minute, 3=Hour, 4=Day)
            unit_number: Number of units per bar
            limit: Max bars to retrieve (max 20,000)
            live: Whether to use live data

        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        # Get contract ID
        contract_id = self._get_contract_id(symbol, live)

        if not contract_id:
            print(f"[ERROR] Could not get contract ID for {symbol}")
            return None

        try:
            url = f"{self.base_url}/api/History/retrieveBars"

            payload = {
                "contractId": contract_id,
                "live": live,
                "startTime": start_time.strftime("%Y-%m-%dT%H:%M:%S"),
                "endTime": end_time.strftime("%Y-%m-%dT%H:%M:%S"),
                "unit": unit,
                "unitNumber": unit_number,
                "limit": min(limit, 20000),  # API max is 20,000
                "includePartialBar": True
            }

            response = requests.post(
                url,
                json=payload,
                headers=self._get_headers(),
                timeout=30
            )

            if response.status_code == 200:
                data = response.json()

                # Handle response structure
                bars = None
                if isinstance(data, dict):
                    bars = data.get('bars') or data.get('result') or data.get('data')
                elif isinstance(data, list):
                    bars = data

                if not bars:
                    print(f"[WARNING] No bars returned for {symbol}")
                    return None

                # Convert to DataFrame
                df = pd.DataFrame(bars)

                # Rename columns to standard format
                column_mapping = {
                    'time': 'timestamp',
                    't': 'timestamp',
                    'timestamp': 'timestamp',
                    'o': 'open',
                    'open': 'open',
                    'h': 'high',
                    'high': 'high',
                    'l': 'low',
                    'low': 'low',
                    'c': 'close',
                    'close': 'close',
                    'v': 'volume',
                    'volume': 'volume'
                }

                # Check which columns exist and rename
                for old_col, new_col in column_mapping.items():
                    if old_col in df.columns and old_col != new_col:
                        df.rename(columns={old_col: new_col}, inplace=True)

                # Parse timestamp
                if 'timestamp' in df.columns:
                    df['timestamp'] = pd.to_datetime(df['timestamp'])
                    # Sort by timestamp
                    df = df.sort_values('timestamp').reset_index(drop=True)

                print(f"[TOPSTEPX] Fetched {len(df)} bars for {symbol}")
                return df

            else:
                print(f"[ERROR] Failed to retrieve bars: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"[ERROR] Failed to fetch bars for {symbol}: {e}")
            return None

    def get_current_bars(self, symbol: str, timeframe: str = "1m", count: int = 100) -> Optional[pd.DataFrame]:
        """
        Fetch recent OHLC bars for a symbol

        Args:
            symbol: Futures symbol (e.g., 'NQ', 'GC')
            timeframe: Timeframe for bars (e.g., '1m', '5m', '15m')
            count: Number of bars to fetch

        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        # Parse timeframe
        unit_number = int(timeframe.replace('m', '').replace('h', '').replace('d', ''))

        if 'm' in timeframe:
            unit = 2  # Minute
        elif 'h' in timeframe:
            unit = 3  # Hour
        elif 'd' in timeframe:
            unit = 4  # Day
        else:
            unit = 2  # Default to minute

        # Calculate time range - API requires UTC
        end_time = datetime.utcnow()

        if unit == 2:  # Minutes
            start_time = end_time - timedelta(minutes=count * unit_number + 60)
        elif unit == 3:  # Hours
            start_time = end_time - timedelta(hours=count * unit_number + 1)
        else:  # Days
            start_time = end_time - timedelta(days=count * unit_number + 1)

        return self.get_bars(symbol, start_time, end_time, unit, unit_number, count)

    def get_session_bars(self, symbol: str, timeframe: str = "1m") -> Optional[pd.DataFrame]:
        """
        Fetch all bars from today's trading session start

        Args:
            symbol: Futures symbol
            timeframe: Timeframe for bars

        Returns:
            DataFrame with today's session bars
        """
        # Calculate session start time - API requires UTC
        now = datetime.utcnow()
        # Note: config times are in ET, need to convert to UTC
        # For now using UTC time directly - this method may not be used
        session_start = now.replace(
            hour=config.SESSION_START_HOUR,
            minute=config.SESSION_START_MINUTE,
            second=0,
            microsecond=0
        )

        # If before session start, use previous day's session
        if now < session_start:
            session_start -= timedelta(days=1)

        # Parse timeframe
        unit_number = int(timeframe.replace('m', '').replace('h', '').replace('d', ''))

        if 'm' in timeframe:
            unit = 2  # Minute
        elif 'h' in timeframe:
            unit = 3  # Hour
        elif 'd' in timeframe:
            unit = 4  # Day
        else:
            unit = 2  # Default to minute

        # Calculate how many bars we need
        minutes_elapsed = int((now - session_start).total_seconds() / 60)
        bars_needed = max(minutes_elapsed, 100)  # At least 100 bars

        return self.get_bars(symbol, session_start, now, unit, unit_number, bars_needed)

    def _get_mock_data(self, symbol: str, count: int) -> pd.DataFrame:
        """
        Generate mock OHLC data for testing without API access

        This simulates realistic price movement for development/testing
        """
        import numpy as np

        print(f"[MOCK] Generating mock data for {symbol}")

        # Base prices for different symbols
        base_prices = {
            "NQ": 21000,
            "GC": 2650,
        }

        base_price = base_prices.get(symbol, 100)

        # Generate timestamps
        now = datetime.now()
        timestamps = [now - timedelta(minutes=i) for i in range(count, 0, -1)]

        # Generate realistic price movement
        returns = np.random.randn(count) * 0.001  # 0.1% volatility
        prices = base_price * (1 + returns).cumprod()

        data = []
        for i, ts in enumerate(timestamps):
            open_price = prices[i]
            high_price = open_price * (1 + abs(np.random.randn() * 0.0005))
            low_price = open_price * (1 - abs(np.random.randn() * 0.0005))
            close_price = np.random.uniform(low_price, high_price)
            volume = np.random.randint(100, 1000)

            data.append({
                'timestamp': ts,
                'open': round(open_price, 2),
                'high': round(high_price, 2),
                'low': round(low_price, 2),
                'close': round(close_price, 2),
                'volume': volume
            })

        return pd.DataFrame(data)

    def get_current_price(self, symbol: str) -> Optional[float]:
        """Get the current market price for a symbol"""
        df = self.get_current_bars(symbol, "1m", 1)
        if df is not None and not df.empty:
            return df.iloc[-1]['close']
        return None

    def get_multi_timeframe_data(self, symbol: str) -> Dict[str, pd.DataFrame]:
        """
        Fetch multiple timeframes for ICT multi-timeframe analysis

        Args:
            symbol: Futures symbol (e.g., 'NQZ5', 'GCZ5')

        Returns:
            Dictionary with keys: 'daily', '1h', '15m', '5m', '1m'
        """
        print(f"[TOPSTEPX] Fetching multi-timeframe data for {symbol}...")

        result = {}

        # Get CURRENT time in UTC - API requires UTC timestamps
        now = datetime.utcnow()

        # Daily - get last 10 days for trend context
        daily_start = now - timedelta(days=10)
        result['daily'] = self.get_bars(symbol, daily_start, now, unit=4, unit_number=1, limit=10)

        # 1 Hour - get last 48 hours of hourly data
        h1_start = now - timedelta(hours=48)
        result['1h'] = self.get_bars(symbol, h1_start, now, unit=3, unit_number=1, limit=48)

        # 15 Minutes - get last 24 hours (96 bars)
        m15_start = now - timedelta(hours=24)
        result['15m'] = self.get_bars(symbol, m15_start, now, unit=2, unit_number=15, limit=100)

        # 5 Minutes - get last 12 hours (144 bars)
        m5_start = now - timedelta(hours=12)
        result['5m'] = self.get_bars(symbol, m5_start, now, unit=2, unit_number=5, limit=150)

        # 1 Minute - get last 2 hours for real-time price (includes partial bar)
        m1_start = now - timedelta(hours=2)
        result['1m'] = self.get_bars(symbol, m1_start, now, unit=2, unit_number=1, limit=120)

        # Check what we successfully fetched
        for tf, df in result.items():
            if df is not None and not df.empty:
                last_bar_time = df.iloc[-1]['timestamp']
                time_ago = (now - last_bar_time.replace(tzinfo=None)).total_seconds()
                if time_ago < 60:
                    print(f"  [{tf}]: {len(df)} bars (last: {time_ago:.0f}s ago)")
                else:
                    print(f"  [{tf}]: {len(df)} bars (last: {time_ago/60:.0f}m ago)")
            else:
                print(f"  [{tf}]: No data")

        return result


if __name__ == "__main__":
    # Test the TopStepX client
    print("Testing TopStepX Client...")

    client = TopStepXClient(
        api_key=config.TOPSTEPX_API_KEY,
        base_url=config.TOPSTEPX_BASE_URL,
        username=config.TOPSTEPX_USERNAME
    )

    if client.account_id:
        # Test fetching data
        for symbol in config.SYMBOLS:
            print(f"\n{'='*60}")
            print(f"Testing {symbol}")
            print('='*60)

            df = client.get_session_bars(symbol)
            if df is not None and not df.empty:
                print(f"Fetched {len(df)} bars")
                print(f"\nFirst few bars:")
                print(df.head())
                print(f"\nLast few bars:")
                print(df.tail())
                print(f"\nCurrent price: ${df.iloc[-1]['close']:.2f}")
            else:
                print(f"Failed to fetch data for {symbol}")
    else:
        print("\n[ERROR] Could not get account ID. Please check your API key.")
