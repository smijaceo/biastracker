"""
Test Professional 3-Factor Bias System
"""

from datetime import datetime
import requests
import config
from topstepx_client import TopStepXClient
from pro_bias_engine import ProBiasEngine

print("="*70)
print("3-FACTOR BIAS SYSTEM")
print("="*70)
print("Structure + VWAP + Opening Range")
print("="*70)

# Connect
client = TopStepXClient(
    api_key=config.TOPSTEPX_API_KEY,
    base_url=config.TOPSTEPX_BASE_URL,
    username=config.TOPSTEPX_USERNAME
)

engine = ProBiasEngine()
results = []

# Process symbols
for symbol in config.SYMBOLS:
    print(f"\n{'='*70}")
    print(f"Processing {symbol}...")
    print('='*70)

    # Get data
    timeframe_data = client.get_multi_timeframe_data(symbol)

    # Calculate bias (use 5m for VWAP/OR, 1m for current price)
    state = engine.calculate_bias(
        symbol,
        timeframe_data['daily'],
        timeframe_data['5m'],
        timeframe_data.get('1m')
    )

    if state:
        short_name = symbol[:2]

        print(f"\nFINAL BIAS: {state.bias}")
        print(f"Price: ${state.current_price:.2f}")
        print(f"\n3-Factor Breakdown:")
        print(f"  [1] Market Structure: {state.market_structure}")
        print(f"  [2] VWAP Position:    {state.vwap_position} (VWAP: ${state.vwap:.2f})")
        print(f"  [3] Opening Range:    {state.opening_range} (${state.or_low:.2f} - ${state.or_high:.2f})")
        print(f"\nReasoning:")
        for line in state.reasoning.split('\n'):
            print(f"  {line}")

        results.append(state)
    else:
        print(f"[ERROR] Could not calculate bias for {symbol}")

# Send notification
if results:
    print(f"\n{'='*70}")
    print("Sending to phone...")
    print('='*70)

    # Build message
    lines = []
    for state in results:
        short_name = state.symbol[:2]

        # Simple clean format
        lines.append(f"{short_name}: {state.bias}\n${state.current_price:.2f}")

        # Add factor summary
        factors = []
        if state.market_structure == "BULLISH":
            factors.append("Structure UP")
        elif state.market_structure == "BEARISH":
            factors.append("Structure DOWN")

        if state.vwap_position == "BULLISH":
            factors.append("Above VWAP")
        elif state.vwap_position == "BEARISH":
            factors.append("Below VWAP")

        if state.opening_range == "BULLISH":
            factors.append("Broke OR High")
        elif state.opening_range == "BEARISH":
            factors.append("Broke OR Low")

        if factors:
            lines.append(" | ".join(factors))

    message = '\n\n'.join(lines)

    # Send
    try:
        # Determine priority
        priority = 1 if any("STRONG" in r.bias for r in results) else 0

        payload = {
            "token": config.PUSHOVER_API_TOKEN,
            "user": config.PUSHOVER_USER_KEY,
            "message": message,
            "title": "Daily Bias (3-Factor)",
            "priority": priority,
            "sound": "cashregister" if priority == 1 else "cosmic"
        }

        response = requests.post(
            "https://api.pushover.net/1/messages.json",
            data=payload,
            timeout=10
        )

        if response.status_code == 200:
            print("\n[SUCCESS] Sent to phone!")
            print(f"\nMessage:")
            print("-" * 70)
            print(message)
            print("-" * 70)
        else:
            print(f"[ERROR] {response.status_code}: {response.text}")
    except Exception as e:
        print(f"[ERROR] {e}")

print(f"\n{'='*70}")
print("Test complete!")
print('='*70)
