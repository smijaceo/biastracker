"""
Configuration file for Intraday Bias Tracker
"""

# TopStepX API Configuration
TOPSTEPX_API_KEY = "jq5EaAEnW9KNgXtoOpGxWxExtSJ2UsQIQoa42Zo3qeg="
TOPSTEPX_USERNAME = "voydeyt"
TOPSTEPX_BASE_URL = "https://api.topstepx.com"

# Pushover Configuration
PUSHOVER_USER_KEY = "uhf3jsvv2vevoj99yomizyrfdtb5ve"
PUSHOVER_API_TOKEN = "ahircd7o5wyy4uwetq8m9ejmqjeeyk"

# Trading Configuration
# Found from TopStepX: NQZ5 (Dec 2025), GCZ5 (Dec 2025)
# Also available: MNQZ5 (Micro NQ), MGCZ5 (Micro GC)
SYMBOLS = ["NQZ5", "GCZ5"]  # Futures symbols to track
TIMEFRAME = "1m"  # 1-minute bars for real-time updates
UPDATE_INTERVAL = 3600  # Check every hour (3600 seconds)

# Bias Scoring Thresholds
STRONG_BULLISH = 70
WEAK_BULLISH = 55
NEUTRAL_LOW = 45
NEUTRAL_HIGH = 54
WEAK_BEARISH = 44
STRONG_BEARISH = 30

# VWAP Settings
VWAP_THRESHOLD_STRONG = 0.005  # 0.5% away from VWAP
VWAP_THRESHOLD_WEAK = 0.002    # 0.2% away from VWAP

# Session Times (ET)
SESSION_START_HOUR = 9
SESSION_START_MINUTE = 30
SESSION_END_HOUR = 16
SESSION_END_MINUTE = 0

# Notification Settings
QUIET_HOURS_START = 16  # Don't send notifications after market close
QUIET_HOURS_END = 9     # Don't send notifications before market open
